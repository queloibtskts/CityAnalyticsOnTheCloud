import React from "react";

const Reportpage = () => (
  <div>
    Report
  </div>
)

export default Reportpage;