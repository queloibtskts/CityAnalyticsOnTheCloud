# COMP90024_Assignment2

  ### front end
    cd frondend/ docker-compose up

  ### back end
    cd backend/ docker-compose up
  ### deployment with docker ref
  https://codeburst.io/develop-create-react-app-with-docker-fb7fa3869ba
  https://stackoverflow.com/questions/54841515/node-and-react-running-with-docker-compose-yml-file

  ### deployment with ansible ref
  https://github.com/FlashXu/CCC_A2/blob/master/ansible/roles/deploy/templates/instance4.yaml.j2
  ### Couchdb
  #### in your own ubuntu
    cd /OpenStack_Docker_Couchdb
    sudo ./docker.sh
  #### Then, input your password
